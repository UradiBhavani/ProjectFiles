package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cg.DAO.AdminInterfaceDAOImpl;
import com.cg.DAO.IAdminInterfaceDAO;
import com.cg.dto.ShowClaimDetails;


@WebServlet("/adminSearchBasedOnClaimNumber")
public class AdminSearchBasedOnClaimNumberServlet extends HttpServlet{
	
	static final Logger LOGGER = Logger.getLogger(AdminSearchBasedOnClaimNumberServlet.class);
	
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IAdminInterfaceDAO adminInterfaceDAO = new AdminInterfaceDAOImpl();
		
		try {
			
			LOGGER.info("Inside Admin Search Based On Claim Number Servlet ");
			
			String username = (String) request.getSession().getAttribute("username");
			int claimNumber = Integer.parseInt(request.getParameter("claimNumber"));
			List<ShowClaimDetails> claimList = adminInterfaceDAO.getClaimDetails(claimNumber);
			
			
			request.setAttribute("ClaimList", claimList);
			request.getRequestDispatcher("adminShowClaimList.jsp").forward(request, response);
		} catch (Exception e) {
			LOGGER.error("Error while searching the data based on claim number");
		}
	}
}
