package com.cg.exceptions;

public class InsuranceException extends Exception{
	public InsuranceException(String message) {
		super(message);
	}
}
