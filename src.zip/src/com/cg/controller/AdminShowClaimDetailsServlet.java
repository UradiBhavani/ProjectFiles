package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cg.DAO.AdminInterfaceDAOImpl;
import com.cg.DAO.IAdminInterfaceDAO;
import com.cg.dto.ShowClaimDetails;


@WebServlet("/adminShowClaimDetails")
public class AdminShowClaimDetailsServlet extends HttpServlet{
	
	static final Logger LOGGER = Logger.getLogger(AdminShowClaimDetailsServlet.class);
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IAdminInterfaceDAO adminInterfaceDAO = new AdminInterfaceDAOImpl();
		
		try {
			
			LOGGER.info("Inside Admin Show Claim Details Servlet.");
			
			
			String username = (String) request.getSession().getAttribute("username");
			List<ShowClaimDetails> claimList = adminInterfaceDAO.getClaimDetails();
			
			
			request.setAttribute("ClaimList", claimList);
			request.getRequestDispatcher("adminShowClaimList.jsp").forward(request, response);
			
		} catch (Exception e) {
			
			LOGGER.error("Error while fetching the claim details.");
			
		}
	}

}
