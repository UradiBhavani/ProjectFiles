package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.WebFault;

import org.apache.log4j.Logger;

import com.cg.DAO.AdminInterfaceDAOImpl;
import com.cg.DAO.IAdminInterfaceDAO;
import com.cg.dto.UserRole;
@WebServlet("/profileCreation")
public class ProfileCreationServlet extends HttpServlet{
	
	static final Logger LOGGER = Logger.getLogger(ProfileCreationServlet.class);
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IAdminInterfaceDAO adminInterfaceDAO = new AdminInterfaceDAOImpl();
		
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher=null;
		
		try {
			
			LOGGER.info("Inside Profile Creation Servlet.");
			
			String agentId="";
			if(request.getParameter("roleCode").equals("usr")) {
				agentId=request.getParameter("agentId");
			}
			else agentId=null;
			
			
			UserRole userRole = new UserRole();
			userRole.setUserName(request.getParameter("userName"));
			userRole.setPassword(request.getParameter("password"));
			userRole.setRoleCode(request.getParameter("roleCode"));
			userRole.setAgentId(agentId);
			userRole.setAccountNumber(Integer.parseInt(request.getParameter("accountNumber")));
			
			
			
			
			int id = adminInterfaceDAO.createProfile(userRole);
			if(id==1) {
				LOGGER.info("Successfully created profile");
				dispatcher = request.getRequestDispatcher("admin.jsp");
				dispatcher.forward(request, response);
					
			} 
			else {
				
				LOGGER.info("Couldn't create the profile");
				out.println("<h1><font color = 'red'> Encountered one problem please try again after some time. </font></h1>");
				dispatcher = request.getRequestDispatcher("loginErrorPage.html");
				dispatcher.forward(request, response);
			}
		} catch (Exception e) {
			
			LOGGER.error("Error While creating the profile");
		}
	}
}
