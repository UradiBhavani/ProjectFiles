package com.cg.queries;

public class QueryConstraints {
	
	
	

}
