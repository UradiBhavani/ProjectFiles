package com.cg.utility;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.controller.LoginServlet;
import com.cg.exceptions.InsuranceException;

import oracle.jdbc.driver.OracleDriver;

public class JDBCUtility {
	
	static Connection connection = null;
	static final Logger LOGGER = Logger.getLogger(LoginServlet.class);
	
	public static Connection getConnection() throws InsuranceException {
		Driver driver = new OracleDriver();
		
		try {
			DriverManager.registerDriver(driver);
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Capgemini1234");
		} catch (SQLException e) {
			LOGGER.error("Couldn't connect to the database");
			throw new InsuranceException("Error while connecting to the database");
		}
		
		return connection;
	}

}
